**1. The Problem (1-2 câu)**
- ✓ Ai cụ thể đang gặp vấn đề? : Các vận động viên bộ môn quyền tiêu chuẩn Taekwondo và các HLV bộ môn quyền tiêu chuẩn Taekwondo thường gặp khó khăn khi muốn năng cao khả năng thực hiện bài quyền theo các tiêu chí của liên đoàn Taekwondo thế giới (WT) do khó có thể tự quan sát, đánh giá chính xác và nhận được phản hồi chi tiết.
- ✓ Vấn đề diễn ra với tần suất nào? : Việc tập luyện và thi đấu ở các giải đấu lớn đòi hỏi sự chính xác gần như tuyệt đối về mặt kỹ thuật, tốc độ, sức mạnh, nhịp điệu, cân bằng và sự kết nối giữa các động tác, điều mà việc tập luyện truyền thống rất khó đáp ứng một cách đầy đủ và khách quan.
- ✓ Tác động kinh tế / vận hành? : Tốn nhiều thời gian, công sức và chi phí cho việc tập luyện, huấn luyện, do phải định kỳ đi tập huấn nước ngoài, hoặc phải quay video nhiều lần để gửi cho huấn luyện viên góp ý.


**2. The Insight (1 câu)**
- ✓ Điều phản trực giác — không obvious : AI có khả năng phát hiện những sai lệch nhỏ nhất giữa các tư thế, động tác của video mẫu với video tự thực hiện của vận động viên, ngay cả những sai lệch mà con người khó có thể phát hiện được.
- ✓ Bạn thấy được vì có background đặc biệt : Tôi có background là một vận động viên Taekwondo với nhiều năm kinh nghiệm huấn luyện.
- ❌ "Người ta cần AI tốt hơn" (mọi founder đều nói)

**3. The Solution (3 câu)**
- ✓ Câu 1: Sản phẩm làm gì : nhập đầu vào là 2 video, một video mẫu từ Kukkiwon Hàn Quốc, một video tự tập luyện của vận động viên. Sản phẩm sẽ trả về đánh giá, nhận xét và chỉ ra các điểm cần cải thiện.    
- ✓ Câu 2: Differentiator (vs ChatGPT, đối thủ) : trên thì trường chưa có sản phẩm tương tự.
- ✓ Câu 3: AI giúp specific như thế nào :  Nhận xét từ AI có độ chính xác cao, chi tiết, khách quan và có thể trả về kết quả ngay lập tức.
- ❌ Liệt kê 12 features

**4. Why Now (1-2 câu)**
- ✓ Lý do timing cụ thể (cost AI giảm, behavior thay đổi, regulation mới...) : Sự phát triển mạnh của các mô hình thi giác máy tính cho phép phân tích chuyển động của con người một cách chi tiết và chính xác với chi phí triển khai hợp lý.
- ❌ "AI đang phát triển mạnh" (quá generic)

**5. Traction / Proof (số cụ thể)**
- ✓ Dùng số từ Day 17 PMF + Day 18 Unit Economics : 
→ LTV / CAC Ratio	380.00x
→ CAC Payback Period	0.1 tháng
- ✓ Aha moment metric cụ thể : 72% vận động viên đánh giá cao độ chính xác, chi tiết, khách quan của nhận xét từ AI. 100% vận động viên cho biết sẽ tiếp tục sử dụng sản phẩm trong tương lai.
- ❌ "Đang test với một vài shop quen biết"

**6. The Ask (1-2 câu)**
- ✓ Cần GÌ (vốn? pilot? mentor?): Vốn từ angel investor để phát triển sản phẩm, 
- ✓ BAO NHIÊU : 500 triệu
- ✓ Để làm GÌ trong 12 tháng: Sử dụng AI agent để xây dựng và tối ưu hóa hệ thống đánh giá bài quyền, phát triển hệ thống đề xuất các bài tập bổ trợ các động tác trong bài quyền mà vận động viên thực hiện chưa tốt. 
- ❌ "Bất kỳ sự hỗ trợ nào cũng được"