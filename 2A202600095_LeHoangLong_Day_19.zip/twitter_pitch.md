
Bọn em xây dựng PoomsaeAI, nền tảng tập luyện Taekwondo dựa trên AI, giúp các vận động viênự phân tích và cải thiện kỹ thuật thực hiện bài quyền một cách chính xác, khách quan và tức thì. Hiện tại, team bọn em đã có PMF với số liệu đáng khích lệ, LTV/CAC Ratio 380.00x và CAC Payback Period 0.1 tháng. 72% vận động viên đánh giá cao độ chính xác, chi tiết, khách quan của nhận xét từ AI. 100% vận động viên cho biết sẽ tiếp tục sử dụng sản phẩm trong tương lai. 

Bọn em đang kêu gọi angel investor để phát triển sản phẩm, vốn gọi là 500 triệu và hướng tới 3000 người dùng trong 12 tháng tới.

