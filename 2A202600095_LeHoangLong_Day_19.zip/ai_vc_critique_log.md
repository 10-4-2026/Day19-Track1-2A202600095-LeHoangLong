# 1. Pitch gốc trước critique

Bọn em xây dựng PoomsaeAI, nền tảng tập luyện Taekwondo dựa trên AI, giúp các vận động viênự phân tích và cải thiện kỹ thuật thực hiện bài quyền một cách chính xác, khách quan và tức thì. Hiện tại, team bọn em đã có PMF với số liệu đáng khích lệ, LTV/CAC Ratio 380.00x và CAC Payback Period 0.1 tháng. 72% vận động viên đánh giá cao độ chính xác, chi tiết, khách quan của nhận xét từ AI. 100% vận động viên cho biết sẽ tiếp tục sử dụng sản phẩm trong tương lai. 

Bọn em đang kêu gọi angel investor để phát triển sản phẩm, vốn gọi là 500 triệu và hướng tới 3000 người dùng trong 12 tháng tới.

# 2. Conversation với AI (full feedback)

- Listen, I’ve sat through 50 of these since Monday. If I hear "disrupt" one more time, I’m going to start investing in physical bookstores and fax machines just for the peace of mind. You’ve got a niche, which is better than most "GPT-wrappers" I see, but you’re making some classic mistakes that would get you laughed out of a Monday morning partner meeting.

Here is the cold, hard reality of your pitch:
- 1. THE 8-SECOND TEST

Verdict: FAIL.

Your first sentence is a mouthful of academic definitions. By the time you finished saying "Các vận động viên bộ môn quyền tiêu chuẩn Taekwondo," I was already checking my email.

    Why it fails: You are selling a tool, not a transformation. Investors don't care about "difficulty in observing movements"; they care about winning.

    What works: The fact that you mentioned "World Taekwondo (WT) standards." That’s the only part that felt professional.

- 2. THE INSIGHT TEST

Verdict: GENERIC.

Your "Insight" is: "AI can see things humans can't."
Newsflash: Every AI founder in every domain (radiology, manufacturing, tennis) says this. It’s not an insight; it’s a brochure for Computer Vision 101.

    The Sharper Angle: Your real insight should be about the data gap. Elite Poomsae is about "Kibon" (basics)—the specific tension in a forearm block or the exact 45-degree angle of a foot that a general model like MediaPipe misses.

    Fix: Your insight isn't that AI is better; it's that standard AI is actually bad at Taekwondo, and you have the proprietary dataset of Kukkiwon-standard movements to bridge that gap.

3. THE OPENAI THREAT

Moat Status: NON-EXISTENT.

If OpenAI or Google releases a specialized sports-analysis layer for Gemini/GPT-5 next week, you are dead.

    Why your moat is weak: You said your differentiator is "there is no similar product." That is never a moat; that is just a temporary head start.

    The challenge: How do you get the data that OpenAI can't scrape from YouTube? If you don't have a partnership with a national federation or a proprietary dataset of sensor-tagged elite athletes, you’re just a UI sitting on top of a vision model.

4. THE NUMBERS TEST

Verdict: RIDICULOUS / RED FLAG.

    "LTV/CAC Ratio: 380.00x": This number is so high it’s actually insulting. A "good" SaaS ratio is 3x. 380x tells me your "CAC" is basically zero because you’re just texting your friends at the Thang Long University club. It doesn't scale.

    "CAC Payback 0.1 months": Again, this suggests you have no real marketing engine.

    "72% found it accurate": That means 28%—nearly 1 in 3—found it inaccurate. In a sport of "absolute precision," a 30% error rate is a disqualifier for an elite athlete.

5. THE WEAKEST LINE

The Quote: "trên thị trường chưa có sản phẩm tương tự." (There are no similar products on the market.)

    Why I hate it: It’s almost always false (SwingVision for tennis, Mustard for baseball) and it shows a lack of competitive research. Even if true, it implies there might not be a market.

    The Rewrite: "While general fitness apps focus on reps, we own the 'Gold Standard' dataset for WT-certified Poomsae, creating a high-switching-cost ecosystem for professional dojangs."

Final Advice:

You’re asking for 500 million (VND, I assume). That's a tiny "lifestyle" check. If you want VC money, stop talking like a Taekwondo coach and start talking like a Data Monopolist.

One question to guide your next move:
How do you move from being a "video analysis tool" to becoming the "Official Digital Scoring System" that every tournament is forced to pay for?

# 3. Quyết định Accept/Reject/Partial cho mỗi point

- 1. THE 8-SECOND TEST **Accept:** AI đúng. Pitch cần ngắn gọn, súc tích và đi vào trọng tâm hơn. Nội dung sẽ viết lại như sau:

PoomsaeAI là nền tảng tập luyện Taekwondo dựa trên AI, giúp các vận động viênự nâng cao khả năng chiến thắng tại cái giải thi đấu. Hiện tại, team bọn em đã có LTV/CAC Ratio 380.00x và CAC Payback Period 0.1 tháng. 70% người dùng đánh giá cao nhận xét từ AI và sẽ tiếp tục sử dụng sản phẩm trong tương lai. 

Bọn em đang kêu gọi angel investor để phát triển sản phẩm, vốn gọi là 500 triệu và hướng tới 3000 người dùng trong 12 tháng tới.

- 2. THE INSIGHT TEST **Accept:** AI đúng. Pitch cần nói rõ hơn về insight. Nội dung sẽ viết lại như sau: Các giải pháp AI có sẵn khó lòng cập nhật liên tục kịp với tốc độ thay đổi tiết tấu và cách thức thực hiện bài quyền của liên đoàn Taekwondo thế giới (WT). Giải pháp của bọn em giải quyết được vấn đề này ngay tức thì thông qua việc sử dụng video mẫu mới nhất từ Kukkiwon Hàn Quốc. 

- 3. THE OPENAI THREAT **Partial** AI đúng, tuy nhiên việc  đưa ra lý do thuyết phục hơn về Moat là cần thiết.

- 4. THE NUMBERS TEST **Reject:** AI sai. LTV/CAC Ratio và CAC Payback  hiện tại chỉ là con số tạm thời do bọn em đang ở giai đoạn đầu, chưa marketing, chưa có nhiều doanh thu từ admob. Ngoài ra, 72% và 100% là số liệu survey, chưa phải số liệu thực tế.

- 5. THE WEAKEST LINE **Reject:** AI sai. Điểm "trên thị trường chưa có sản phẩm tương tự" vẫn còn nhiều ý kiến trái chiều.

# 4. Lý do với mỗi quyết định

- Pitch cần ngắn gọn, súc tích và đi vào trọng tâm hơn
- Pitch cần nói rõ hơn về insight. 
- Pitch cần nói rõ hơn về Moat. 
- Pitch cần nói rõ hơn về số liệu. 
- Pitch cần nói rõ hơn về Weakest Line. 

